import { Outlet } from "react-router-dom";
import MentorSidebar from "./MentorSidebar";
import "./MentorLayout.css";

export default function MentorLayout() {
  return (
    <div className="mentor-layout">
      <MentorSidebar />
      <main className="mentor-content">
        <Outlet />
      </main>
    </div>
  );
}