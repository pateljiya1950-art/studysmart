import { useEffect, useState } from "react";
import { getMentorDashboard } from "../../services/mentorApi";

export default function MentorDashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    getMentorDashboard().then(setData);
  }, []);

  if (!data) return <p>Loading...</p>;

  return (
    <div>
      <h2>Welcome, {data.profile?.name}</h2>

      <div className="mentor-cards">
        <Card title="Students Assigned" value={data.totalStudents} />
        <Card title="Pending Requests" value={data.pendingRequests} />
        <Card title="Sessions Scheduled" value={data.upcomingSessions} />
        <Card title="Avg Rating" value={data.avgRating ?? 0} highlight />
      </div>
    </div>
  );
}

function Card({ title, value, highlight }) {
  return (
    <div className={`card ${highlight ? "highlight" : ""}`}>
      <h4>{title}</h4>
      <p>{value}</p>
    </div>
  );
}