import { useState } from "react";
import { saveMentorProfile } from "../../services/mentorApi";
import { useNavigate } from "react-router-dom";

export default function MentorProfile() {
  const [department, setDepartment] = useState("");
  const [experienceYears, setExperienceYears] = useState("");
  const [maxStudents, setMaxStudents] = useState("");
  const navigate = useNavigate();

  const submit = async e => {
    e.preventDefault();

    await saveMentorProfile({
      department,
      experienceYears: Number(experienceYears),
      maxStudents: Number(maxStudents)
    });

    navigate("/mentor-dashboard");
  };

  return (
    <form onSubmit={submit}>
      <input
        placeholder="Department"
        onChange={e => setDepartment(e.target.value)}
      />
      <input
        type="number"
        placeholder="Experience Years"
        onChange={e => setExperienceYears(e.target.value)}
      />
      <input
        type="number"
        placeholder="Max Students"
        onChange={e => setMaxStudents(e.target.value)}
      />
      <button>Save</button>
    </form>
  );
}
