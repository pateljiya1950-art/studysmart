import { Link } from "react-router-dom";
import "./MentorLayout.css";

export default function MentorSidebar() {
  return (
    <aside className="mentor-sidebar">
      <h3>Mentor Panel</h3>

      <Link to="/mentor-dashboard">Dashboard</Link>
      <Link to="/mentor/profile">Profile</Link>
      <Link to="/mentor/requests">Requests</Link>
      <Link to="/mentor/students">Students</Link>
      <Link to="/mentor/sessions">Sessions</Link>
      <Link to="/mentor/assignments">Assignments</Link>
      <Link to="/mentor/availability">Availability</Link>
      <Link to="/mentor/feedback">Feedback</Link>
      <Link to="/mentor/analytics">Analytics</Link>
    </aside>
  );
}