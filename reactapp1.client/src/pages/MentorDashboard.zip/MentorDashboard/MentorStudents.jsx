import { useEffect, useState } from "react";
import { authFetch } from "../../services/authService";

export default function MentorStudents() {
  const [students, setStudents] = useState([]);

  useEffect(() => {
    authFetch("/mentor/students").then(setStudents);
  }, []);

  return (
    <div>
      <h2>Assigned Students</h2>
      {students.map(s => (
        <div key={s.studentId}>
          <h4>{s.name}</h4>
          <p>Course: {s.course}</p>
        </div>
      ))}
    </div>
  );
}