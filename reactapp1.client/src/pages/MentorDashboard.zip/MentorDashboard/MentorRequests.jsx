import { useEffect, useState } from "react";
import { getMentorRequests, respondToRequest } from "../../services/mentorApi";
import "./MentorRequests.css";

export default function MentorRequests() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    getMentorRequests().then(setRequests);
  }, []);

  const handle = async (id, action) => {
    await respondToRequest(id, action);
    setRequests(req => req.filter(r => r.requestId !== id));
  };

  return (
    <div className="requests-card">
      <h3>Mentor Requests</h3>

      {requests.length === 0 && <p>No pending requests</p>}

      {requests.map(r => (
        <div key={r.requestId} className="request-row">
          <div>
            <strong>{r.studentName}</strong>
            <span>{r.skill}</span>
          </div>

          <div className="actions">
            <button onClick={() => handle(r.requestId, "accept")}>Accept</button>
            <button className="reject" onClick={() => handle(r.requestId, "reject")}>Reject</button>
          </div>
        </div>
      ))}
    </div>
  );
}
